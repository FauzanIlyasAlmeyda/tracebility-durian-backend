<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{

    /**
     * REGISTER
     */
    public function register(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string|max:100',
            'last_name' => 'required|string|max:100',
            'phone' => 'required|string|max:20|unique:users,phone',
            'email' => 'required|email|max:191|unique:users,email',
            'password' => 'required|min:8|confirmed',
            'role' => 'required|in:petani,pengepul,distributor,umkm,konsumen',
        ]);

        $user = User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'phone' => $request->phone,
            'email' => $request->email,
            'password' => $request->password,
            'role' => $request->role,
            'username' => null,
        ]);

        $token = $user->createToken('flutter')->plainTextToken;

        return response()->json([
            'success' => true,
            'message' => 'Register berhasil',
            'data' => [
                'user' => [
                    'id' => $user->id,
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'phone' => $user->phone,
                    'email' => $user->email,
                    'role' => $user->role,
                ],
                'token' => $token,
                'dashboard' => $user->role
            ]
        ],201);
    }

    /**
     * LOGIN
     */
    public function login(Request $request)
    {
        $request->validate([
            'identifier' => 'required',
            'password' => 'required',
            'role' => 'required|in:petani,pengepul,distributor,umkm,konsumen',
        ]);

        $identifier = $request->identifier;

        $user = User::where('email',$identifier)
            ->orWhere('username',$identifier)
            ->first();

        if(!$user){
            return response()->json([
                'success'=>false,
                'message'=>'Akun tidak ditemukan'
            ],404);
        }

        if(!Hash::check($request->password,$user->password)){
            return response()->json([
                'success'=>false,
                'message'=>'Password salah'
            ],401);
        }

        if($user->role != $request->role){
            return response()->json([
                'success'=>false,
                'message'=>'Role tidak sesuai'
            ],403);
        }

        $user->update([
            'last_login_at'=>now()
        ]);

        $token = $user->createToken('flutter')->plainTextToken;

        return response()->json([
            'success'=>true,
            'message'=>'Login berhasil',
            'data'=>[
                'user'=>[
                    'id'=>$user->id,
                    'first_name'=>$user->first_name,
                    'last_name'=>$user->last_name,
                    'email'=>$user->email,
                    'phone'=>$user->phone,
                    'role'=>$user->role,
                ],
                'token'=>$token,
                'dashboard'=>$user->role
            ]
        ]);
    }

    /**
     * USER LOGIN
     */
    public function me(Request $request)
    {
        return response()->json([
            'success'=>true,
            'data'=>$request->user()
        ]);
    }

    /**
     * LOGOUT
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'success'=>true,
            'message'=>'Logout berhasil'
        ]);
    }

}